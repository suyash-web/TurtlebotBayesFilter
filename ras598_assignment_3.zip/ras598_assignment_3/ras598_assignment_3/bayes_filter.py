import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry, Path, OccupancyGrid
from marker_msgs.msg import MarkerDetection
from geometry_msgs.msg import PoseStamped
from visualization_msgs.msg import Marker, MarkerArray
import numpy as np
from scipy.ndimage import gaussian_filter
from tf_transformations import euler_from_quaternion
import re
import os

class BayesFilter3D(Node):
    def __init__(self, world_file_path):
        super().__init__('bayes_filter_3d_node')
        
        # --- CONFIGURATION ---
        self.world_size = 16.0         # Total width/height of the environment (meters)
        self.resolution = 0.2          # Size of one grid cell (meters)
        self.theta_res = 10            # Angular resolution (degrees)
        self.grid_dim = int(self.world_size / self.resolution)
        self.theta_dim = int(360 / self.theta_res)

        # --- ROS PUBLISHERS ---
        self.costmap_pub = self.create_publisher(OccupancyGrid, 'viz/belief_costmap', 10)
        self.landmark_pub = self.create_publisher(MarkerArray, 'viz/landmarks', 10)
        self.gt_path_pub = self.create_publisher(Path, 'viz/gt_path', 10)
        self.odom_path_pub = self.create_publisher(Path, 'viz/odom_path', 10)
        
        # Path messages initialization
        self.gt_path_msg = Path()
        self.gt_path_msg.header.frame_id = 'map'
        self.odom_path_msg = Path()
        self.odom_path_msg.header.frame_id = 'map'

        # --- FILTER STATE INITIALIZATION ---
        self.landmarks = self._parse_world_file(world_file_path)
        self.initial_pose = [-7.0, -7.0, 90.0]  # [x, y, theta_degrees] DO NOT CHANGE THIS!
        
        # Trajectory tracking for visualization
        self.odom_x, self.odom_y = self.initial_pose[0], self.initial_pose[1]
        self.odom_th = np.radians(self.initial_pose[2])
        
        # Initialize self.belief in initialize_belief()
        self.initialize_belief(pose=self.initial_pose)

        self.last_odom_pose = None

        # --- SUBSCRIPTIONS ---
        self.create_subscription(Odometry, '/odom', self.odom_callback, 10)
        self.create_subscription(Odometry, '/ground_truth', self.gt_callback, 10)
        self.create_subscription(MarkerDetection, '/fiducials', self.fiducial_callback, 10)

        # Refresh landmarks in RViz
        self.create_timer(1.0, self._publish_landmarks)

        # Print Landmarks Locations
        self.get_logger().info("--- Landmark Locations ---")
        for tid, pos in self.landmarks.items():
            lx, ly = pos
            self.get_logger().info(f"ID {tid}: x={lx:.2f}, y={ly:.2f}")
        self.get_logger().info("---------------------------")
    
    # -------------------------------------------------------------------------
    # UTILITY & VISUALIZATION FUNCTIONS
    # You don't need to change the function code for these functions.
    # -------------------------------------------------------------------------

    def _parse_world_file(self, path):
        """Parses Stage .world file for landmark positions."""
        found = {}
        if not os.path.exists(path): return found
        with open(path, 'r') as f:
            content = f.read()
        block_pattern = re.compile(r'my_block\s*\((.*?)\)', re.DOTALL)
        pose_pattern = re.compile(r'pose\s*\[\s*([-\d.]+)\s+([-\d.]+)')
        id_pattern = re.compile(r'fiducial_return\s+(\d+)')
        for block_content in block_pattern.findall(content):
            p_match = pose_pattern.search(block_content)
            id_match = id_pattern.search(block_content)
            if p_match and id_match:
                found[int(id_match.group(1))] = (float(p_match.group(1)), float(p_match.group(2)))
        return found

    def _publish_landmarks(self):
        """Publishes landmark locations as Markers for RViz."""
        ma = MarkerArray()
        for tid, (tx, ty) in self.landmarks.items():
            # Cylinder Marker
            c = Marker()
            c.header.frame_id = 'map'
            c.id = tid
            c.type = Marker.CYLINDER
            c.action = Marker.ADD
            c.pose.position.x, c.pose.position.y, c.pose.position.z = tx, ty, 0.5
            c.scale.x, c.scale.y, c.scale.z = 0.3, 0.3, 1.0
            c.color.r, c.color.g, c.color.b, c.color.a = 1.0, 0.0, 0.0, 1.0
            ma.markers.append(c)
            # Text ID Marker
            t = Marker()
            t.header.frame_id = 'map'
            t.id = tid + 1000
            t.type = Marker.TEXT_VIEW_FACING
            t.text = f"ID: {tid}"
            t.pose.position.x, t.pose.position.y, t.pose.position.z = tx, ty + 0.5, 1.2
            t.scale.z = 0.4 
            t.color.r, t.color.g, t.color.b, t.color.a = 1.0, 1.0, 1.0, 1.0
            ma.markers.append(t)
        self.landmark_pub.publish(ma)

    def _publish_costmap(self):
        """Publishes the 2D projected belief as an OccupancyGrid."""
        if not hasattr(self, 'belief'):
            return
        grid = OccupancyGrid()
        grid.header.frame_id = 'map'
        grid.header.stamp = self.get_clock().now().to_msg()
        grid.info.resolution, grid.info.width, grid.info.height = self.resolution, self.grid_dim, self.grid_dim
        grid.info.origin.position.x, grid.info.origin.position.y = -8.0, -8.0
        belief_2d = np.sum(self.belief, axis=2)
        belief_grid = belief_2d.T
        max_val = np.max(belief_grid)
        if max_val > 0:
            data = (belief_grid / max_val * 100).astype(np.int8)
        else:
            data = np.zeros_like(belief_grid, dtype=np.int8)

        grid.data = data.flatten().tolist()
        self.costmap_pub.publish(grid)
    
    
    # -------------------------------------------------------------------------
    #  ASSIGNMENT TASKS
    # -------------------------------------------------------------------------

    def gt_callback(self, msg):
        """Updates Ground Truth path for visualization."""
        p = PoseStamped()
        p.header = msg.header
        p.pose.position.x, p.pose.position.y = msg.pose.pose.position.x, msg.pose.pose.position.y
        self.gt_path_msg.poses.append(p)
        self.gt_path_pub.publish(self.gt_path_msg)

    def initialize_belief(self, pose=None):
        """
        TASK 1: Initialize the 3D Probability Density Function (PDF).
        If 'pose' is provided, initialize the belief as a localized 
        distribution (e.g., a point or Gaussian). If 'pose' is None, 
        initialize a Uniform distribution across the entire state space.
        """
        # TODO: Create a numpy array of shape (grid_dim, grid_dim, theta_dim)
        # TODO: Assign probability values and ensure they sum to 1.0
        if pose is None:
            self.belief = np.ones((self.grid_dim, self.grid_dim, self.theta_dim), dtype=np.float64)
        else:
            x0, y0, th0_deg = pose
            ix0, iy0, ith0 = self.real_to_grid(x0, y0, th0_deg)
            self.belief = np.zeros((self.grid_dim, self.grid_dim, self.theta_dim), dtype=np.float64)
            self.belief[ix0, iy0, ith0] = 1.0
            self.belief = gaussian_filter(self.belief, sigma=[2.0, 2.0, 1.0], mode='wrap')
        self.belief /= self.belief.sum()

    def real_to_grid(self, x, y, theta_deg):
        """
        TASK 2(a): Coordinate Transformation (Real -> Grid).
        Convert continuous world coordinates to discrete 3D grid indices.
        Returns: (ix, iy, ith)
        """
        ix  = int(np.clip((x + 8.0) / self.resolution, 0, self.grid_dim - 1))
        iy  = int(np.clip((y + 8.0) / self.resolution, 0, self.grid_dim - 1))
        ith = int(theta_deg / self.theta_res) % self.theta_dim
        return ix, iy, ith

    def grid_to_real(self):
        """
        TASK 2(b): Coordinate Transformation (Grid -> Real).
        Generate 3D numpy arrays containing the real-world (x, y, theta) 
        values for every cell in the belief grid.
        Returns: rx, ry, rth (all numpy arrays of shape self.belief.shape)
        """
        ix_vec  = np.arange(self.grid_dim)
        iy_vec  = np.arange(self.grid_dim)
        ith_vec = np.arange(self.theta_dim)
        x_vec   = -8.0 + (ix_vec  + 0.5) * self.resolution
        y_vec   = -8.0 + (iy_vec  + 0.5) * self.resolution
        th_vec  = np.radians(ith_vec * self.theta_res)
        rx, ry, rth = np.meshgrid(x_vec, y_vec, th_vec, indexing='ij')
        return rx, ry, rth

    def predict(self, curr_msg, last_msg):
        """
        TASK 3: Motion Model (Prediction).
        Implement the 'Turn-Go-Turn' model. Update self.belief to reflect 
        the robot's movement between last_msg and curr_msg.
        """
        # TODO: Calculate deltas (d_rot1, d_trans, d_rot2)
        q     = curr_msg.pose.pose.orientation
        q_old = last_msg.pose.pose.orientation
        yaw_cur = np.degrees(euler_from_quaternion([q.x,     q.y,     q.z,     q.w    ])[2]) % 360
        yaw_old = np.degrees(euler_from_quaternion([q_old.x, q_old.y, q_old.z, q_old.w])[2]) % 360

        dx = curr_msg.pose.pose.position.x - last_msg.pose.pose.position.x
        dy = curr_msg.pose.pose.position.y - last_msg.pose.pose.position.y
        d_trans = np.sqrt(dx**2 + dy**2)

        travel_dir = np.degrees(np.arctan2(dy, dx)) % 360.0
        d_rot1 = (travel_dir - yaw_old + 180) % 360 - 180
        d_rot2 = (yaw_cur - travel_dir  + 180) % 360 - 180

        if d_trans < 1e-6 and abs(d_rot1 + d_rot2) < 0.1:
            return

        # TODO: Apply shifts along spatial and angular axes
        rot1_bins = int(round(d_rot1 / self.theta_res))
        if rot1_bins:
            self.belief = np.roll(self.belief, rot1_bins, axis=2)

        dx_cells = int(round(dx / self.resolution))
        dy_cells = int(round(dy / self.resolution))
        if dx_cells:
            self.belief = np.roll(self.belief, dx_cells, axis=0)
        if dy_cells:
            self.belief = np.roll(self.belief, dy_cells, axis=1)

        rot2_bins = int(round(d_rot2 / self.theta_res))
        if rot2_bins:
            self.belief = np.roll(self.belief, rot2_bins, axis=2)

        # TODO: Apply a diffusion filter (e.g., Gaussian) to model uncertainty
        self.belief = gaussian_filter(self.belief, sigma=[0.8, 0.8, 0.6], mode='wrap')
        self.belief = np.clip(self.belief, 1e-300, None)
        self.belief /= self.belief.sum()

    def update_measurement(self, lx, ly, meas_range, meas_bearing_rad):
        """
        TASK 4: Measurement Model (Update).
        Correct the belief using a landmark sighting.
        """
        # TODO: Calculate expected range and bearing for every cell in the grid
        rx, ry, rth = self.grid_to_real()
        delta_x = lx - rx
        delta_y = ly - ry
        exp_range   = np.sqrt(delta_x**2 + delta_y**2)
        exp_bearing = (np.arctan2(delta_y, delta_x) - rth + np.pi) % (2 * np.pi) - np.pi

        # TODO: Compute the Gaussian likelihood and multiply by current belief
        sigma_r = 0.5
        sigma_b = np.radians(10.0)
        range_err   = exp_range - meas_range
        bearing_err = (exp_bearing - meas_bearing_rad + np.pi) % (2 * np.pi) - np.pi
        likelihood  = (np.exp(-0.5 * (range_err   / sigma_r) ** 2) *
                       np.exp(-0.5 * (bearing_err / sigma_b) ** 2) + 1e-300)
        self.belief *= likelihood
        self.belief  = np.clip(self.belief, 1e-300, None)

        # TODO: Re-normalize the belief
        # WARN: If you change the function definition, make sure to change it accordingly in  _fiducial_callback()
        self.belief /= self.belief.sum()


    def odom_callback(self, msg):
        """Handles robot motion, trajectory visualization and performas the Prediction update."""
        if self.last_odom_pose is None:
            self.last_odom_pose = msg
            return
        
        q = msg.pose.pose.orientation
        curr_yaw_deg = np.degrees(euler_from_quaternion([q.x, q.y, q.z, q.w])[2]) % 360
        
        q_old = self.last_odom_pose.pose.pose.orientation
        old_yaw_deg = np.degrees(euler_from_quaternion([q_old.x, q_old.y, q_old.z, q_old.w])[2]) % 360

        # Calculates the differential odometry
        dx = msg.pose.pose.position.x - self.last_odom_pose.pose.pose.position.x
        dy = msg.pose.pose.position.y - self.last_odom_pose.pose.pose.position.y
        dth = (curr_yaw_deg - old_yaw_deg + 180) % 360 - 180 

        # Update and Publish Odom Path
        self.odom_th += np.radians(dth)
        fwd = np.sqrt(dx**2 + dy**2)
        self.odom_x += fwd * np.cos(self.odom_th)
        self.odom_y += fwd * np.sin(self.odom_th)

        p = PoseStamped()
        p.header = msg.header
        p.pose.position.x, p.pose.position.y = self.odom_x, self.odom_y
        self.odom_path_msg.poses.append(p)
        self.odom_path_pub.publish(self.odom_path_msg)

        # Run the prediction loop only when there is sufficient motion
        if np.sqrt(dx**2 + dy**2) > 0.001 or abs(dth) > 0.1:
            self.predict(msg, self.last_odom_pose)
            self.last_odom_pose = msg
            self._publish_costmap()
    
    def fiducial_callback(self, msg):
        """
        TASK 5: Fiducial Callback.
        Performs the Measurement update for every landmark (also called marker) seen by the robot
        """
        for marker in msg.markers:
            lid = int(marker.ids[0])
            if lid not in self.landmarks:
                continue
            lx, ly = self.landmarks[lid]
            rel_x = marker.pose.position.x
            rel_y = marker.pose.position.y
            meas_range = np.sqrt(rel_x**2 + rel_y**2)
            meas_bearing_rad = np.arctan2(rel_y, rel_x)
            self.update_measurement(lx, ly, meas_range, meas_bearing_rad)

        # Publishes the probability distribution costmap
        self._publish_costmap() # Dont remove this line
    

def main():
    rclpy.init()

    world_path = os.path.expanduser("~/ros2_ws/src/stage_ros2/world/cave.world")
    if not os.path.exists(world_path):
        print("\n" + "="*50)
        print("ERROR: World file not found!")
        print(f"Path attempted: {world_path}")
        print("-" * 50)
        print("FIX: Please open your script and update the 'world_path' variable")
        print("to match your ROS 2 workspace name (e.g., ~/dev_ws/src/...)")
        print("="*50 + "\n")
        return # Exit the program gracefully


    node = BayesFilter3D(world_path)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt: pass
    finally: rclpy.shutdown()

if __name__ == '__main__':
    main()
