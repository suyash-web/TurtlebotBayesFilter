import sys
import os
from launch import LaunchDescription, LaunchService
from launch_ros.actions import Node
from launch.actions import ExecuteProcess, TimerAction
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    s_dir = get_package_share_directory("ras598_assignment_3")
    rviz_path = os.path.join(s_dir, "bayes.rviz")

    return LaunchDescription([
        ExecuteProcess(
            cmd=[
                "ros2", "launch", "stage_ros2", "demo.launch.py",
                "world:=cave", "use_stamped_velocity:=false",
            ],
            env={**os.environ, "QT_QPA_PLATFORM": "wayland"},
            output="screen",
            name="stage_simulator",
        ),
        TimerAction(period=3.0, actions=[
            ExecuteProcess(
                cmd=["rviz2", "-d", rviz_path],
                output="screen",
                name="rviz2",
            )
        ]),
        TimerAction(period=5.0, actions=[
            Node(
                package="ras598_assignment_3",
                executable="bayes_filter",
                name="bayes_filter_3d_node",
                output="screen",
            )
        ]),
    ])


def main():
    service = LaunchService()
    service.include_launch_description(generate_launch_description())
    print("-------------- Starting assignment 3 -------------")
    return service.run()


if __name__ == "__main__":
    sys.exit(main())
