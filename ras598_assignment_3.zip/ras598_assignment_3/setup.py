from setuptools import find_packages, setup

package_name = 'ras598_assignment_3'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name, ['bayes_launch.py']),
        ('share/' + package_name, ['bayes.rviz']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Suyash',
    maintainer_email='sdhir5@asu.edu',
    description='Bayes Filter',
    license='MIT',
    extras_require={
        'test': ['pytest'],
    },
    entry_points={
        'console_scripts': [
            'bayes_filter = ras598_assignment_3.bayes_filter:main',
        ],
    },
)
